import React, { useState, useEffect } from "react";
import axios from "axios";
import TeacherHome from "./TeacherHome";
import "./AssignmentManagement.css";

const AssignmentManagement = () => {
  const [assignments, setAssignments] = useState([]);
  const [newAssignment, setNewAssignment] = useState({ name: "", questions: "" });
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    axios
      .get("http://localhost:8080/assignments")
      .then((response) => setAssignments(response.data))
      .catch((error) => console.error("Error fetching assignments:", error));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewAssignment({ ...newAssignment, [name]: value });
  };

  const handleAddAssignment = () => {
    if (newAssignment.name && newAssignment.questions) {
      axios
        .post("http://localhost:8080/assignments", newAssignment)
        .then((response) => {
          setAssignments([...assignments, response.data]);
          setNewAssignment({ name: "", questions: "" });
        })
        .catch((error) => console.error("Error adding assignment:", error));
    }
  };

  const handleDeleteAssignment = (id) => {
    axios
      .delete(`http://localhost:8080/assignments/${id}`)
      .then(() => setAssignments(assignments.filter((a) => a.id !== id)))
      .catch((error) => console.error("Error deleting assignment:", error));
  };

  const currentAssignment = assignments[currentIndex];

  return (
    <TeacherHome>
      <div className="assignment-management-container">
        <h1>Assignment Management</h1>
        <div className="assignment-form">
          <input
            type="text"
            name="name"
            placeholder="Assignment Name"
            value={newAssignment.name}
            onChange={handleChange}
          />
          <textarea
            name="questions"
            placeholder="Assignment Questions"
            value={newAssignment.questions}
            onChange={handleChange}
          />
          <button className="add-btn" onClick={handleAddAssignment}>
            Add Assignment
          </button>
        </div>

        <div className="assignments-list">
          <h2>Assignments</h2>
          {currentAssignment ? (
            <div key={currentAssignment.id} className="assignment-card">
              <p>
                <strong>Name:</strong> {currentAssignment.name}
              </p>
              <p>
                <strong>Questions:</strong> {currentAssignment.questions}
              </p>
              <button
                className="delete-btn"
                onClick={() => handleDeleteAssignment(currentAssignment.id)}
              >
                Delete
              </button>
            </div>
          ) : (
            <p>No assignments available.</p>
          )}
        </div>

        <div className="pagination">
          <button
            className="pagination-button"
            onClick={() => setCurrentIndex((prev) => Math.max(prev - 1, 0))}
            disabled={currentIndex === 0}
          >
            Prev
          </button>
          <button
            className="pagination-button"
            onClick={() =>
              setCurrentIndex((prev) => Math.min(prev + 1, assignments.length - 1))
            }
            disabled={currentIndex === assignments.length - 1}
          >
            Next
          </button>
        </div>
      </div>
    </TeacherHome>
  );
};

export default AssignmentManagement;
