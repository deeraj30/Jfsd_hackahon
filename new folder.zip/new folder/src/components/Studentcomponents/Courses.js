import React, { useEffect, useState } from "react";
import axios from "axios";
import StudentHome from "./StudentHome"; // Ensure StudentHome has the navigation bar included
import "./Courses.css";

const Courses = () => {
  const [resources, setResources] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  // Fetch resources from the backend on component mount
  useEffect(() => {
    axios
      .get("http://localhost:8080/resources")
      .then((response) => setResources(response.data))
      .catch((error) => console.error("Error fetching resources:", error));
  }, []);

  // Calculate pagination
  const indexOfLastResource = currentPage * itemsPerPage;
  const indexOfFirstResource = indexOfLastResource - itemsPerPage;
  const currentResources = resources.slice(indexOfFirstResource, indexOfLastResource);

  const totalPages = Math.ceil(resources.length / itemsPerPage);

  // Event handlers for pagination
  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <StudentHome>
      <div className="courses-container">
        <h1>Available Topics</h1>
        {resources.length === 0 ? (
          <p className="no-resources">No Topics available yet.</p>
        ) : (
          <>
            <div className="resources-grid">
              {currentResources.map((resource) => (
                <div key={resource.id} className="resource-card">
                  <h2>{resource.topic}</h2>
                  {resource.youtube && (
                    <p>
                      <strong>YouTube:</strong>{" "}
                      <a
                        href={resource.youtube}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Click here
                      </a>
                    </p>
                  )}
                  {resource.otherresources && (
                    <div>
                      <strong>Other Resources:</strong>
                      {resource.otherresources.split(",").map((link, index) => (
                        <p key={index}>
                          <a
                            href={link.trim()}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            {link.trim()}
                          </a>
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Pagination Buttons */}
            <div className="pagination">
              <button
                onClick={handlePreviousPage}
                disabled={currentPage === 1}
                className="pagination-button"
              >
                Previous
              </button>
              <span>
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className="pagination-button"
              >
                Next
              </button>
            </div>
          </>
        )}
      </div>
    </StudentHome>
  );
};

export default Courses;
