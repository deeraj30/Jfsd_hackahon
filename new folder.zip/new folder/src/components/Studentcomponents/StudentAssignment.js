import React, { useEffect, useState } from "react";
import axios from "axios";
import StudentHome from "./StudentHome"; // Ensure StudentHome includes navigation
import "./StudentAssignment.css";

const StudentAssignment = () => {
  const [assignments, setAssignments] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 2;
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [userDetails, setUserDetails] = useState({});

  // Fetch user details from localStorage
  useEffect(() => {
    const details = JSON.parse(localStorage.getItem("userDetails"));
    if (details) {
      setUserDetails(details);
    } else {
      alert("User details not found. Please sign in.");
    }
  }, []);

  // Fetch assignments and submissions
  useEffect(() => {
    if (!userDetails.email) return;

    axios
      .get("http://localhost:8080/assignments")
      .then((response) => setAssignments(response.data))
      .catch((error) => console.error("Error fetching assignments:", error));

    axios
      .get(`http://localhost:8080/api/assignments/submissions?email=${userDetails.email}`)
      .then((response) => {
        const submittedAssignments = response.data;
        setAssignments((prev) =>
          prev.map((assignment) => ({
            ...assignment,
            submitted: submittedAssignments.some(
              (submission) =>
                submission.assignmentName === assignment.name &&
                submission.studentEmail === userDetails.email
            ),
          }))
        );
      })
      .catch((error) => console.error("Error fetching submissions:", error));
  }, [userDetails]);

  const handleFileSelection = (e, assignmentId) => {
    const file = e.target.files[0];
    setUploadedFiles((prev) => ({
      ...prev,
      [assignmentId]: file,
    }));
  };

  const handleMarkAsDone = (assignmentId, assignmentName) => {
    const file = uploadedFiles[assignmentId];
    if (!file) {
      alert("Please upload a file before marking as done.");
      return;
    }

    const formData = new FormData();
    formData.append("studentName", userDetails.name);
    formData.append("studentEmail", userDetails.email);
    formData.append("assignmentName", assignmentName);
    formData.append("file", file);

    axios
      .post("http://localhost:8080/api/assignments/mark-done", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then(() => {
        alert("Assignment marked as done successfully!");
        setAssignments((prev) =>
          prev.map((assignment) =>
            assignment.id === assignmentId
              ? { ...assignment, status: "Done", submitted: true }
              : assignment
          )
        );
      })
      .catch((error) => {
        console.error("Error marking assignment as done:", error);
        alert("Failed to mark assignment as done. Please try again.");
      });
  };

  return (
    <StudentHome>
      <div className="assignments-container">
        <h1>Assignments</h1>
        {assignments.length === 0 ? (
          <p>No assignments available yet.</p>
        ) : (
          <div className="assignments-grid">
            {assignments.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage).map((assignment) => (
              <div key={assignment.id} className="assignment-card">
                <h2>{assignment.name}</h2>
                <p><strong>Questions:</strong> {assignment.questions}</p>
                {assignment.submitted ? (
                  <p>Already Submitted</p>
                ) : (
                  <>
                    <input
                      type="file"
                      onChange={(e) => handleFileSelection(e, assignment.id)}
                      disabled={assignment.submitted}
                    />
                    <button
                      onClick={() => handleMarkAsDone(assignment.id, assignment.name)}
                      disabled={!uploadedFiles[assignment.id]}
                    >
                      {assignment.status === "Done" ? "Done" : "Mark as Done"}
                    </button>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
        <div className="pagination">
          <button onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))} disabled={currentPage === 1}>
            Previous
          </button>
          <span>Page {currentPage}</span>
          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, Math.ceil(assignments.length / itemsPerPage)))}
            disabled={currentPage === Math.ceil(assignments.length / itemsPerPage)}
          >
            Next
          </button>
        </div>
      </div>
    </StudentHome>
  );
};

export default StudentAssignment;
