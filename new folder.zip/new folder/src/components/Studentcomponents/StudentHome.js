import React from 'react';
import { Link } from 'react-router-dom';
import './StudentHome.css';

const StudentHome = ({ children }) => {
    return (
        <div className="student-dashboard">
            <header className="navbar">
                <h1 className="navbar-title">Student Dashboard</h1>
                <nav>
                    <ul className="nav-links">
                        <li><Link to="/Courses">Course</Link></li>
                        <li><Link to="/assignments">Assignments</Link></li>
                        <li><Link to="/studentannouncements">Announcements</Link></li>
                        <li><Link to="/student-progress">Progress</Link></li>
                        <li><Link to="/studentqueries">Queries</Link></li>
                        <li><Link to="/feedback">Feedback</Link></li>
                        <li><Link to="/studentprofile">Profile</Link></li>
                        <Link to="/signin" className="logout">Logout</Link>
                    </ul>
                </nav>
            </header>
            <main className="dashboard-content">
                {children}
            </main>
        </div>
    );
};

export default StudentHome;
