import React, { useState, useEffect } from "react";
import axios from "axios";
import StudentHome from "./StudentHome"; // Ensure StudentHome includes the navigation bar
import "./StudentAnnouncements.css";

const StudentAnnouncements = () => {
  const [announcements, setAnnouncements] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [userDetails, setUserDetails] = useState({}); // To store logged-in student details

  useEffect(() => {
    // Fetch user details from local storage
    const details = JSON.parse(localStorage.getItem("userDetails"));
    if (details) {
      setUserDetails(details); // Set the user details (name, email, etc.)
      fetchAnnouncements(details.email); // Fetch announcements using the student's email
    } else {
      alert("User details not found. Please sign in.");
    }
  }, []);

  const fetchAnnouncements = (email) => {
    axios
      .get(`http://localhost:8080/api/announcements/student/${email}`)
      .then((response) => {
        setAnnouncements(response.data);
      })
      .catch((error) => {
        console.error("Error fetching announcements:", error);
        setErrorMessage("Failed to fetch announcements.");
      });
  };

  return (
    <StudentHome>
      <div>
        <h1>Student Announcements</h1>
        {userDetails.name && <h2>Welcome, {userDetails.name}!</h2>}
        {errorMessage && <p className="error">{errorMessage}</p>}

        <ul>
          {announcements.map((announcement) => (
            <li key={announcement.id}>
              <p>{announcement.announcementText}</p>
              <p>
                <strong>Created At:</strong> {new Date(announcement.createdAt).toLocaleString()}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </StudentHome>
  );
};

export default StudentAnnouncements;
